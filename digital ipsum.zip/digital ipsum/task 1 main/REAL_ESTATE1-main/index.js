import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);


function App() {
  return (
    <div>
      <div className="logo-container"> </div>
    </div>
  );
}

export default App;

// App.css
.logo-container {
  background-image: url("https://www.cyberandbeyond.com/sites/default/files/cyberandbeyond-logo-web.svg");
  background-size: contain; /* Adjust to fit the container */
  background-repeat: no-repeat;
  width: 150px; /* Set your desired width */
  height: 50px; /* Set your desired height */
}


