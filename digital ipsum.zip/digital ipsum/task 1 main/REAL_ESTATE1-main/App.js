
import './App.css';
import Home from './Components/Home';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { comments } from "@fortawesome/free-solid-svg-icons"


function App() {
  return (
    <div className="App">
      <Home/>
      
    </div>
  );
}

export default App;
