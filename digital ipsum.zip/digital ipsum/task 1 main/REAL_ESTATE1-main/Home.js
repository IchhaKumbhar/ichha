import React from 'react';
import Navbar from './Navbar';

const Home = () => {
  return <div className='home-container'>
    <Navbar/>
    </div>;

};

export default Home