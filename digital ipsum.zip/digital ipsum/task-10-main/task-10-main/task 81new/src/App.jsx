// src/App.jsx

import React from 'react';
import AppRouter from './components/AppRouter';

const App = () => {
  return (
    <div>
      <div className="logo-container"> </div>
      background-image: url("your-logo.png");
  background-size: contain; /* Adjust to fit the container */
  background-repeat: no-repeat;
  width: 150px; /* Set your desired width */
  height: 50px; /* Set your desired height */
    </div>
  );
}

