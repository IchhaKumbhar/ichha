import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import './index.css';
import Ichha from './Ichha';

import Dashboard from './pages/Dashboard';
import FrameComponent1 from './pages/FrameComponent3';


const router = createBrowserRouter([
  { path: '/', element: <Ichha /> },
{ path: '/FrameComponent1', element: <FrameComponent1 /> },
]);

export default function App() {
  return (
    <div>
      <div className="logo-container"> </div>
      background-image: url("https://www.cyberandbeyond.com/sites/default/files/cyberandbeyond-logo-web.svg");
  background-size: contain; /* Adjust to fit the container */
  background-repeat: no-repeat;
  width: 150px; /* Set your desired width */
  height: 50px; /* Set your desired height */
    </div>
  );
}