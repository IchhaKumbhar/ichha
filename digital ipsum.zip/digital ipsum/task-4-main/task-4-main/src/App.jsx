import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import './index.css';
import F12Main from './F12Main';

import LandingPage from './pages/LandingPage';


const router = createBrowserRouter([
  { path: '/', element: <F12Main /> },
{ path: '/LandingPage', element: <LandingPage /> },
]);

export default function App() {
  return (
    <div>
    <div className="logo-container"> </div>
    background-image: url("https://www.cyberandbeyond.com/sites/default/files/cyberandbeyond-logo-web.svg");
    background-size: contain; /* Adjust to fit the container */
  background-repeat: no-repeat;
  width: 150px; /* Set your desired width */
  height: 50px;
  </div>
  );
}